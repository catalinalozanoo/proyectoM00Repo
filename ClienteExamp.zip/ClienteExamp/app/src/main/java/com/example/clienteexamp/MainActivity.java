package com.example.clienteexamp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.microsoft.signalr.HubConnection;
import com.microsoft.signalr.HubConnectionBuilder;
import com.microsoft.signalr.HubConnectionState;

public class MainActivity extends AppCompatActivity {

    Button btn_starts;
    TextView txtMs, txtNm;
    HubConnection hubConnection;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hubConnection = HubConnectionBuilder.create("http://192.168.0.5:53679/movehub").build();
        // Clients.Others.SendAsync(name,message);
        hubConnection.on("Recibemensaje",(name,message)->{

            txtNm.setText(name);
            txtMs.setText(message);
        },String.class,String.class);

        txtNm = (TextView)findViewById(R.id.txtNme);
        txtMs = (TextView)findViewById(R.id.txtMsg);
        btn_starts = (Button)findViewById(R.id.btn_start);

        btn_starts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(btn_starts.getText().toString().toLowerCase().equals("conectar")){
                    if(hubConnection.getConnectionState()== HubConnectionState.DISCONNECTED){
                        hubConnection.start();
                        btn_starts.setText("desconectar");

                        String n  = "nombreId";
                        String m = "mensajeId";

                        txtNm.setText(n);
                        txtMs.setText(m);
                        if(hubConnection.getConnectionState()==HubConnectionState.CONNECTED) {

                            hubConnection.send("MoveFromServer",n,m);
                        }

                    }
                }else if(btn_starts.getText().toString().toLowerCase().equals("desconectar")){
                    if(hubConnection.getConnectionState()==HubConnectionState.CONNECTED)
                        hubConnection.stop();
                    btn_starts.setText("conectar");
                    txtNm.setText("desconectado");
                    txtMs.setText("desconectado");

                }
            }
        });
    }
}
